# STEM Digital Twin — GUI Build Specification

A build-ready prompt/spec for a two-window GUI on top of the existing STEM digital-twin
server. Every control below maps to a **real** RPC on `MicroscopeControlClient` (portable
instrument control) or `SimulationHarness` (twin-only simulation state), so the GUI drives the
actual twin with no new backend work. Values, ranges, and defaults are taken from the current
build.

---

## 0. Architecture & how the GUI talks to the twin

The twin is a Twisted JSON-RPC server (netstring protocol, port 9094) already running in the
notebook. The GUI is a **client** that holds one `STEMClient` (which combines
`MicroscopeControlClient` + `SimulationHarness`) and calls its methods on user actions.

- **Recommended stack:** the twin runs in Colab, so the lowest-friction GUI is **ipywidgets**
  rendered in the notebook itself (no packaging, runs next to the server). If you want a
  standalone desktop app, **PyQt/PySide** or a **Dash/Streamlit** web app work too — the
  backend contract is identical; only the widget toolkit changes.
- **Golden rule for responsiveness:** every acquisition or sample-generation call can take from
  ~0.3 s (a 1024-px image) to tens of seconds (a 4096-px tilted atomic-resolution frame, or generating a fresh
  sample volume). **Run all RPC calls on a worker thread** and post results back to the UI
  thread; never block the event loop. Show a spinner/"busy" state during calls.
- **Two clients, two roles — keep them visually separate in the UI:**
  - `MicroscopeControlClient` = things a *real microscope* also has (stage, beam, mode, FOV/mag,
    resolution, acquire). These belong in **Window 2**.
  - `SimulationHarness` = things only a *simulator* has (which sample, environment, thickness,
    drift/damage injection, reset). These belong in **Window 1**.

```python
from stem_client import STEMClient          # or MicroscopeControlClient + SimulationHarness
client  = STEMClient(host="127.0.0.1", port=9094, timeout=300)
control = client                            # portable control surface
sim     = client                            # simulation-harness surface
control.wait_until_ready(300)               # block until first sample volume is built
```

---

## WINDOW 1 — Sample Registration & Environment

This window **defines the specimen and the conditions it is observed under**, then loads it.
Nothing here exists on a real microscope except implicitly (it's the specimen you happened to
put in and the state of your column) — that's why it's the "simulation" window. Loading is the
commit action; it calls `sim.load_sample(...)` and (optionally) `sim.set_environment(...)`.

### 1.1 Sample selector (dropdown)

Populate from the registry. Show the human-readable `display_name`; keep the internal `name`
as the value. Current samples:

| internal name | display | configurable knobs (besides seed) |
|---|---|---|
| `fcc_single_crystal` | Fe (FCC, γ-austenite) | a_angstrom, atomic_number |
| `bcc_single_crystal` | Fe (BCC, α-ferrite) | a_angstrom, atomic_number |
| `hcp_single_crystal` | Mg (HCP) | a_angstrom, c_over_a, atomic_number |
| `polycrystal_grains` | Polycrystal (Fe FCC, few grains) | **n_grains (2–12)**, **orientation_mode** |
| `dislocation_crystal` | Fe FCC **[111]** with Edge Dislocations (many) | **n_dislocations (1–40)**, **zone_axis**, burgers_A |
| `amorphous_film` | Amorphous Film | atomic_number |
| `au_dispersed` | Au Nanoparticles (Dispersed) | **n_particles (1–50000)** |
| `au_clustered` | Au Nanoparticles (Clustered) | — |
| `au_bimodal` | Au Nanoparticles (Bimodal Size) | — |
| `au_on_substrate` | Au on Substrate (Catalyst) | **n_particles (0–50000)** |
| `core_shell` | Core-Shell Nanoparticles | **n_particles (0–20000)** |
| `shape_assembly` | Shape Assembly (synthetic) | — |
| `atomsk_polycrystal` | Atomsk Polycrystal (file-driven) | file_path, auto_fit, scale_factor |

### 1.2 Dynamic per-sample parameters (build controls from the schema)

**Do not hard-code the parameter controls.** Each sample exposes
`sample.meta.param_schema` — a dict of `{param: {type, min, max}}`. When the user picks a
sample, fetch its schema and render a control per parameter:

- `type: "int"` → integer spinbox / slider with the given `min`/`max`.
- `type: "float"` → float spinbox with `min`/`max` (step ~ (max−min)/100).
- `type: "bool"` → checkbox.
- `type: "str"` **without** `choices` → text field (e.g. `atomsk_polycrystal.file_path`).
- `type: "str"` **with** a `choices` list → **dropdown** populated from `choices`. New in v3;
  `dislocation_crystal.zone_axis` and `polycrystal_grains.orientation_mode` are the first two
  parameters to use it, so a schema-driven builder needs this branch or it will render them as
  free-text and let users type an invalid mode.

Pre-fill each control with the sample's current default (`sample.params[k]`).

The knobs users will most want, called out explicitly per your request:

- **Number of grains** — `polycrystal_grains.n_grains`, int **2–12** (default 4). More grains =
  more boundaries and more distinct diffraction orientations.
- **Number of dislocations** — `dislocation_crystal.n_dislocations`, int **1–40** (default 12).
  This is the "many dislocations" control; higher = more strain, more mosaic spread in
  diffraction, and more visible distortion of the atomic columns at high magnification.
  (Also expose `burgers_A`, the Burgers-vector magnitude, float 0.5–10 Å — **default is now
  2.525 Å**, i.e. |a/2⟨110⟩| = a/√2, the real FCC slip vector, not the full lattice parameter.)
- **Zone axis** — `dislocation_crystal.zone_axis`, **dropdown** {001, 011, 110, 111, 112},
  default **111**. Sets which crystal direction points along the beam, so it changes both the
  projected column pattern and the diffraction net: [001] square, [011] rectangular, **[111]
  hexagonal (default)**, [112] lower symmetry. Label it "Zone axis (beam direction)".
- **Grain orientation mode** — `polycrystal_grains.orientation_mode`, **dropdown**
  {random_zone_axes, random_3d, in_plane}, default **random_zone_axes**. This is a
  legibility-vs-realism control and deserves a tooltip:
  - `random_zone_axes` (default) — each grain sits on a *different low-index zone axis*, so
    grains genuinely differ **and** stay resolvable. Best for demonstrating orientation
    contrast across a boundary.
  - `random_3d` — uniformly random orientation per grain. Physically honest for an untextured
    polycrystal, but a random orientation is almost never near a zone axis, so most grains show
    no resolvable columns and only sparse asymmetric spots.
  - `in_plane` — legacy. Every grain keeps [001] on the beam and is only spun about it, so all
    grains give the *same* square net, merely rotated. Retained for the didactic
    orientation-mapping demo. `max_tilt_deg` applies **only** in this mode.
- **Number of particles** — `au_dispersed.n_particles` (1–50000), `au_on_substrate` (0–50000),
  `core_shell` (0–20000). Particle count / loading.
- **Lattice constant / element** — `a_angstrom` (1–20 Å) and `atomic_number` (1–100) on the
  crystals; `c_over_a` (1.0–2.5) additionally on HCP.
- **Atomsk file** — `file_path` (str), `auto_fit` (bool), `scale_factor` (float). When
  `auto_fit=True` the structure is placed at true physical scale; note this to the user.

### 1.3 Seed field(s) — reproducibility, shown as labeled inputs

Every stochastic sample carries an integer **seed** (label it clearly, e.g. "Structure seed").
Same seed + same parameters ⇒ **bit-identical** sample, so users can explore variants and
return to any one exactly. Range is int `0 … 2147483647`.

- Most samples: the seed param is literally named `seed`.
- `dislocation_crystal`: the seed is `disl_seed` (label it "Dislocation seed").
- Show a small **"🎲 randomize"** button next to each seed that drops in a random int, **and
  always display the resulting number** so it can be written down / re-entered.
- **Also surface the thickness seed here** (see 1.5) — it is a *separate* seed from the
  structure seed, so label them distinctly: "Structure seed" vs "Thickness seed".

### 1.4 Volume resolution (advanced, optional)

`load_sample(..., D, H, W)` sets the voxel volume dimensions (default 64×768×768 for the
registry-built volume; per-load you typically pass e.g. D=40, H=256, W=256). Most users never
touch this; expose it under an "Advanced" expander with a note that **larger volumes take
longer to generate** (this is the "sample registry takes time" cost). Keep H=W.

### 1.5 Thickness selection (per your thickness workflow)

The specimen has a **total physical thickness** (100 nm). At load, the user chooses a **working
thickness** (the slab the beam images through) and a **thickness seed** that decides *where*
within the full 100 nm that slab sits — mirroring how real-specimen thickness varies and where
you land is somewhat arbitrary. Controls:

- **Working thickness (nm)** — slider **1 … total (100)**, default = total. Label: "how thick a
  slab the beam passes through". Thicker ⇒ more signal + more excited diffraction spots.
- **Thickness seed** — int spinbox, with the same randomize+display treatment as 1.3. Label it
  "Thickness seed" and add a read-out showing the resulting z-window, e.g. *"images 30 nm slab
  starting 44.6 nm into the 100 nm specimen"* (comes back from `get_thickness()` as
  `z_start_nm`).

Wire either at load time or after:
```python
sim.load_sample(name, params=params, D=40, H=256, W=256,
                thickness_nm=working_nm, thickness_seed=thickness_seed)
# or, to re-pick thickness without regenerating the sample (simulate navigating to a
# differently-thick region):
sim.set_thickness(thickness_nm=working_nm, thickness_seed=thickness_seed)
info = sim.get_thickness()   # {total_nm, working_nm, z_start_nm, seed} -> show z_start read-out
```

### 1.6 Environment definition (the "conditions" panel)

The environment bundles drift + beam damage + contamination + detector dose. Offer **two
modes**, side by side:

**(A) Preset picker** — a dropdown of the five named scenarios. Applying one calls
`sim.set_environment(name)`. Show a short description and the values it will set (below), so the
user sees what they're getting. Exact preset values in the current build:

| preset | drift vx,vy (px/s), jitter | damage | contamination | dwell µs / DQE / readout e⁻ | thickness override |
|---|---|---|---|---|---|
| `pristine` | 0, 0, 0 (off) | off | off | 20 / 0.9 / 1.0 | — |
| `beam_sensitive` | 2, 1, 0.3 | **on** (thresh 4e3 e⁻/Å², rate 0.7) | off | 10 / 0.8 / 1.5 | — |
| `contaminating` | 3, 2, 0.4 | off | **on** (rate 3.0) | 15 / 0.8 / 1.5 | — |
| `thick_drifting` | **12, 7, 1.0** | off | off | 6 / 0.7 / 2.5 | **90 nm** |
| `low_dose` | 4, 2, 0.5 | on (thresh 2.5e3, rate 0.8) | off | **2** / 0.75 / 2.0 | **25 nm** |

**(B) Custom / expert controls** — expose the underlying knobs directly so users can dial "how
much contamination or drift or anything is happening". These call `sim.set_drift(...)` and
`sim.set_specimen(...)` (both take keyword args; only pass the ones you expose):

- **Drift** (`sim.set_drift`):
  - `enabled` (checkbox) — master on/off.
  - `vx_px_per_s`, `vy_px_per_s` (float sliders, suggest 0–15) — drift velocity. This is the
    dominant "how much drift" control. (Reference: 12,7 = "thick_drifting" is strong.)
  - `line_jitter_px` (float slider, 0–2) — scan-line jitter amplitude.
  - `reset_accum` (button) — zero the accumulated drift offset (re-centres the view).
- **Beam damage** (`sim.set_specimen`):
  - `beam_damage_enabled` (checkbox).
  - `damage_dose_threshold` (float, e⁻/Å², suggest 1e3–1e4) — dose before damage onset; lower =
    more fragile specimen.
  - `damage_rate` (float, 0–2) — how fast contrast is lost past threshold; higher = faster damage.
- **Contamination** (`sim.set_specimen`):
  - `contamination_enabled` (checkbox).
  - `contamination_rate` (float, 0–5) — carbon build-up rate where the beam dwells; higher =
    faster brightening/darkening over successive frames.
- **Detector dose** (via `control.device_settings("haadf", ...)`):
  - `dwell_us` (float, 1–50) — per-pixel dwell; lower = noisier (dose-limited).
  - `dqe` (0–1), `readout_e` (float) — detector quality; expose under Advanced.
- **Reset specimen** (button) — `sim.reset_specimen()` clears accumulated damage/contamination
  maps (fresh area).

> Design tip: give each "how much" slider a qualitative scale label under it — e.g. drift
> velocity: *none · mild · moderate · severe* keyed to ~0 / 3 / 7 / 12 px/s — so users without a
> feel for the units still get intuitive control. Custom controls should **override** a preset
> if changed after one is selected (apply-on-change).

### 1.7 "Register / Load sample" button (commit)

On click, on a worker thread:
```python
sim.load_sample(name, params=collected_params, D=D, H=H, W=W,
                thickness_nm=working_nm, thickness_seed=thickness_seed)
sim.set_environment(preset_name)          # if a preset is chosen; else apply custom set_drift/set_specimen
# then optionally push custom overrides:
sim.set_drift(**custom_drift); sim.set_specimen(**custom_specimen)
```
Then refresh Window 2's read-outs. Show a busy indicator — sample generation can take seconds.
Surface any exception (e.g. bad atomsk file path) in a status line.

---

## WINDOW 2 — Microscope Control & Viewer

This is the "at-the-scope" window: the live image/pattern/spectrum plus the controls a real
operator uses. All calls here are on `MicroscopeControlClient` (portable — the same calls work
on a real backend later).

### 2.1 The viewer (central panel)

A single image canvas that shows the current acquisition, with a title strip showing mode,
FOV, mag, and resolution.

- **Acquire button** (and optional "Live" toggle that re-acquires every N ms — but keep N ≥ the
  frame time, and never overlap calls). Acquisition:
  - **IMG / DIFF:** `img = control.acquire_image("haadf")` → 2-D array → render (grayscale for
    IMG, an "inferno"-style colormap for DIFF). DIFF already has the direct beam removed and
    Bragg spots normalized, so display it directly.
  - **EELS:** `spec = control.acquire_spectrum(ev_min, ev_max, n_channels)` → **line plot**
    (energy-loss x-axis, log-y works well) with the returned `edges` marked as vertical lines.
- Show a **busy spinner** while acquiring; disable Acquire during a call.

### 2.2 Mode selector (radio / segmented control)

`control.set_mode(m)` with `m ∈ {"IMG", "DIFF", "EELS"}`. Switching mode should swap the viewer
render type (image vs image vs line plot) and reveal the mode-specific controls (2.6/2.7).

### 2.3 Stage controls (x, y, z, α, β) with limits

Five controls. **x/y/z are in metres** in the RPC, **α/β in degrees**. In the UI, present x/y/z
in **µm or mm** (convert on the way in/out) and α/β in **degrees**. Enforce the twin's hard
**safety limits** in the widgets (min/max) *and* handle the server's rejection:

| axis | UI unit | limit (RPC) | limit (UI) |
|---|---|---|---|
| x | µm | ±1.5e-3 m | ±1500 µm |
| y | µm | ±1.5e-3 m | ±1500 µm |
| z | µm | ±1.0e-3 m | ±1000 µm |
| α (a) | ° | ±30° | ±30° |
| β (b) | ° | ±30° | ±30° |

- Provide both **absolute** (set-to) and **relative** (nudge ±step) controls; a step-size field
  is handy. Call:
  ```python
  control.set_stage({"x": x_m, "y": y_m, "z": z_m, "a": a_deg, "b": b_deg}, relative=False)
  # or nudge:
  control.set_stage({"a": +step_deg}, relative=True)
  ```
- **The server rejects any move whose target exceeds a limit (nothing moves) and raises.** Catch
  that, keep the widget at the last valid value, and flash the reason in the status line. Clamp
  the widget ranges to the table above so users rarely hit it, but still handle the raise.
- α is the **horizontal** tilt axis, β the **vertical** tilt axis (perpendicular double-tilt
  holder) — you can label them that way. On refresh, read back with `control.get_stage()` →
  `[x, y, z, a, b]`.

### 2.3b Atomic columns are now formed from the sample's real atoms (v3)

Nothing in the GUI has to change for this, but it changes what users should *expect to see*,
so it belongs in your tooltips and demo script.

At high magnification the server no longer draws an idealised lattice. It projects the atoms
the sample actually contains, via the same `get_atoms_in_region` call the diffraction engine
uses. Consequences worth surfacing in the UI:

- **Dislocation strain is visible in the image**, not only in diffraction. Raising
  `n_dislocations` now visibly distorts the columns around each core.
- **Each polycrystal grain images in its own orientation.** Panning `x`/`y` across a grain
  boundary changes the projected column pattern, not just the diffraction net. If you show a
  grain-index readout, `polycrystal_grains.grain_at(cx_um, cy_um)` returns it.
- **Tilt re-projects real 3-D coordinates**, so α/β genuinely smear and split columns.
- Columns are still drawn only when **actually resolvable** (projected spacing ≥ ~3.5 px);
  below that the view stays a clean slab rather than an aliased grid. Because the gate now uses
  the *true projected* column spacing, the magnification at which columns appear differs by
  zone axis — FCC down [111] projects to 1.46 Å columns (= a/√6), not 3.57 Å. Don't hard-code
  "columns appear at 4000 kx"; read it from the current view.

### 2.4 FOV and Magnification (linked pair)

FOV and mag are two views of the same quantity: `mag = MAG_K / fov_metres`,
`MAG_K = 0.0944177811456`. Provide **both fields, linked** — editing one updates the other.

```python
control.set_magnification(mag)             # sets mag; server computes FOV
info = control.get_magnification()         # {"magnification", "field_of_view_um"}
# FOV-first UX: convert the typed FOV to a mag, then set it:
control.set_magnification(0.0944177811456 / (fov_um * 1e-6))
```
Show FOV in µm (or nm when < 1 µm) and mag in "kx" (mag/1000). Reasonable UI range: mag ~1 kx →
20 000 kx (FOV ~19 µm → ~5 nm). Higher mag ⇒ smaller FOV; at high mag the crystals show atomic
columns (below).

### 2.5 Resolution windows (discrete)

A segmented control / dropdown with the **fixed set 1024 / 2048 / 4096** px (default 1024):
```python
control.set_resolution(px)                 # px ∈ {1024,2048,4096}; invalid raises
control.get_resolution()                   # {"resolution_px", "allowed":[1024,2048,4096]}
```
Higher resolution ⇒ smaller pixel for the same FOV ⇒ atomic columns resolve at **lower**
magnification, but cost grows as the **pixel count** — 4× per step up.

**Populate the control from `get_resolution()["allowed"]`, not from a hard-coded list.** The
server is the authority; if the set changes again the UI should follow without a code change.

Measured on CPU (D=40 volume, IMG, columns rendered), untilted vs tilted:

| px | frame buffer | untilted | tilted (α or β ≠ 0) |
|---|---|---|---|
| 1024 | 4 MB | ~0.1 s | ~3 s |
| 2048 | 17 MB | ~0.3 s | ~16 s |
| 4096 | 67 MB | ~1.2 s | ~140 s |

The untilted column exists because the server collapses the depth projection into a single
resample when α = β = 0 (exact, not an approximation). A tilted frame samples a shifted grid
per slice and cannot use it, so **tilt is what makes 4k expensive, not 4k itself.**

UI consequences:
- Put a **"(slower)"** hint on 2048 and a **"(much slower when tilted)"** hint on 4096.
- **Always** acquire off-thread with a cancel affordance; at 4096 + tilt a frame can outlast a
  user's patience, and a frozen window will read as a crash.
- Warn, or offer to zero the tilt, when the user selects 4096 with a non-zero α/β.
- Budget memory: a 4096 frame is 67 MB, so a naive "keep the last 10 frames" history is 670 MB.

### 2.6 Beam: current and voltage

`control.set_beam({...}, relative=False)` / `control.get_beam()`:

- **Probe current (pA)** — `current_pA`, suggest 1–1000 pA. Lower current = noisier (dose).
- **Accelerating voltage (kV)** — `voltage_kV`, typical set {80, 120, 200, 300}. Offer as a
  dropdown of standard values plus a free field.
- (`x`, `y` beam-shift also exist but are advanced; hide by default.)
- **Beam blank/disable** (safety, optional): the backends accept `set_beam(..., disabled=True)`;
  expose a "Blank beam" toggle if you want to mirror the safety interlock.

```python
control.set_beam({"current_pA": current, "voltage_kV": kv}, relative=False)
```

### 2.7 Diffraction controls + the **kinematical ⇄ abTEM toggle**

Show these only in DIFF mode.

- **Kinematical settings** (always available; `control.set_diffraction_settings(**kw)`):
  `aperture_um` (selected-area aperture), `depth_nm` (probed depth), `camera_length_mm`
  (pattern zoom), `beamstop_radius_px` (size of the removed direct-beam disk). Sensible defaults
  aperture_um=0.4, depth_nm=20.
- **Engine toggle — "Diffraction engine: [ Kinematical ⇄ abTEM ]"** (default **Kinematical**):
  - **Kinematical (default):** `control.acquire_image("haadf")` in DIFF mode — the fast built-in
    engine (~sub-second). This is the normal path.
  - **abTEM (dynamical):** when toggled on, **do not** call the server for the pattern. Instead
    compute it with the `abtem_diffraction` module on the **same sample's atoms**, off-thread:
    ```python
    from abtem_diffraction import AbtemDiffraction
    eng = AbtemDiffraction(energy_kev=voltage_kV)        # reuse one instance
    import samples
    s = samples.get_sample(current_sample_name)          # same sample as loaded
    atoms = eng.atoms_from_twin_sample(s, half_width_um=0.02, depth_nm=10,
                                       max_lateral_A=50, max_thickness_A=80)
    # apply the current stage tilt to the atoms (abTEM path is decoupled from the server):
    x,y,z,a,b = control.get_stage()
    atoms = AbtemDiffraction.build_crystal_tilted(...)   # for simple crystals, OR
    # AbtemDiffraction.tilted_atoms(atoms, tilt_deg_x=a, tilt_deg_y=b) for arbitrary samples
    dp = eng.saed(atoms, num_frozen_phonons=0)
    # render with the beam-stop-aware display so spots are visible:
    # (AbtemDiffraction.show clips the direct beam)
    ```
  - **UX for the toggle:** because abTEM takes seconds to tens of seconds, show a clear "computing
    (abTEM)…" state and consider a separate **"Compute dynamical pattern"** button rather than
    auto-refresh, so it isn't triggered on every little change. Add a small **"frozen phonons"**
    spinbox (0–16; >0 adds thermal-diffuse background, slower) for the abTEM path only.
  - **Important behavioral note to surface in a tooltip:** the abTEM path is *decoupled* from the
    server, so **stage α/β do not affect the abTEM pattern automatically** — the GUI must read
    the stage and rotate the atoms (as above). The kinematical path applies α/β on the server
    side automatically.
  - **Dependency note:** abTEM must be installed (`pip install abtem ase`), compatible with the
    twin's NumPy 2.x. If the import fails, grey out the toggle with a tooltip.

### 2.8 Autofocus (optional but nice)

A button → `control.autofocus("haadf", z_range_um=2.0, z_steps=9)`. Its success/failure depends
on the environment (it can diverge under `low_dose`/`beam_sensitive`), which makes a good demo of
the environment settings from Window 1. Show the returned best-z and score.

### 2.9 EELS controls (DIFF-sibling; show in EELS mode)

- Energy range `ev_min`, `ev_max` (defaults 0–1000 eV), `n_channels` (default 1024).
- Acquire → line plot; mark returned `edges` (label + onset_eV). The probe sits at one point
  (same geometry as one 4D-STEM position); the spectrum is a structured dummy — say so in a note.

---

## 3. Cross-cutting behaviours

### 3.1 Reproducibility panel (make seeds first-class)

Because the whole point is *explore-but-reproduce*, add a small always-visible **"Session seeds"**
read-out that shows, at a glance: structure seed, thickness seed, and (if used) environment name
+ any custom drift/damage/contamination values. Add **Copy** (dumps them as a small JSON blob)
and **Load** (re-applies a pasted blob) so an exact state can be shared or revisited. Everything
needed is already returned by `get_thickness()`, `get_drift()`, `get_specimen()`,
`get_environment()`, and the sample params.

### 3.2 Status / log strip

Mirror `sim.get_command_log(last_n=…)` in a collapsible panel so users can see the exact RPC
calls their clicks produced (great for turning a GUI session into a script later).

### 3.3 Threading & safety recap

- All `acquire_*`, `load_sample`, `set_resolution(2048|4096)`, and abTEM calls → worker thread + busy
  state. Debounce sliders (apply on release, not on every tick).
- Respect and surface the stage safety raises; never let the UI think a rejected move succeeded
  — always reconcile against `get_stage()` after a move.
- Reuse one `AbtemDiffraction` instance; don't rebuild it per frame.

### 3.4 Suggested layout

- **Window 1 (Sample Registration):** left column = sample dropdown + dynamic param controls +
  seeds + thickness; right column = environment (preset picker on top, custom drift/damage/
  contamination expanders below); bottom = big **Register/Load** button + status.
- **Window 2 (Control & Viewer):** centre = viewer canvas + Acquire/Live; left rail = mode,
  stage (x/y/z/α/β with nudges), autofocus; right rail = FOV/mag, resolution, beam
  (current/voltage), and (in DIFF) diffraction settings + the Kinematical⇄abTEM toggle.

---

## 4. Minimal call map (quick reference)

```
Window 1 (SimulationHarness):
  load_sample(name, params, D,H,W, thickness_nm, thickness_seed)
  set_environment(name)                         # pristine|beam_sensitive|contaminating|thick_drifting|low_dose
  set_drift(enabled, vx_px_per_s, vy_px_per_s, line_jitter_px, reset_accum)
  set_specimen(beam_damage_enabled, damage_dose_threshold, damage_rate,
               contamination_enabled, contamination_rate)
  set_thickness(thickness_nm, thickness_seed) ; get_thickness()
  reset_specimen() ; get_drift() ; get_specimen() ; get_environment()

Window 2 (MicroscopeControlClient):
  set_mode("IMG"|"DIFF"|"EELS") ; get_mode()
  set_stage({x,y,z,a,b}, relative) ; get_stage()        # x/y/z metres, a/b degrees; limits ±1.5mm/±1.5mm/±1mm/±30°/±30°
  set_beam({current_pA, voltage_kV}, relative) ; get_beam()
  set_magnification(mag) ; get_magnification()          # MAG_K=0.0944177811456 ; mag=MAG_K/fov_m
  set_resolution(1024|2048|4096) ; get_resolution()
  set_diffraction_settings(aperture_um, depth_nm, camera_length_mm, beamstop_radius_px)
  device_settings("haadf", size=, field_of_view_um=, dwell_us=, dqe=, readout_e=)
  acquire_image("haadf")                                # IMG or DIFF (kinematical)
  acquire_spectrum(ev_min, ev_max, n_channels)          # EELS
  autofocus("haadf", z_range_um, z_steps)

abTEM path (only when the DIFF engine toggle = abTEM):
  AbtemDiffraction(energy_kev).atoms_from_twin_sample(sample, ...) -> saed(...)
  # rotate atoms by current stage a,b (build_crystal_tilted / tilted_atoms) — server tilt does NOT apply here
```

---

# ADDENDUM (revision 2) — realistic limits, z display, TIFF save, abTEM toggle

This addendum supersedes the earlier ranges where they differ. It reflects the twin build with
physical drift units and the `twin_io` save helper.

## A1. z (focus) must be shown and adjustable on the Control window

**Requirement:** the microscope-control window must **display the current z value** and let the
user adjust it. z was under-specified before; here it is explicit.

- z is part of the stage: `control.set_stage({"z": z_metres}, relative=…)`; read back with
  `control.get_stage()` → `[x, y, z, a, b]`. **z is in metres in the RPC**; show it in **µm** in
  the UI.
- **Two step sizes** (like a real scope's focus): a **fine/focus** control spanning roughly
  **±5 µm** with ~0.1–0.25 µm steps (this is the range that actually changes focus/PSF), and a
  **coarse** control up to the hard limit **±1000 µm**. Label the fine one "Focus (z)".
- Always render the live **z read-out** (e.g. "z = +1.75 µm") next to the control, refreshed from
  `get_stage()` after every move. Defocus visibly changes the image sharpness (the twin applies a
  z-dependent PSF), so this doubles as a manual-focus tool alongside `autofocus()`.
- Keep z in the stage group with x, y, α, β. Suggested control-window stage block:
  `x, y` (navigation, ±1500 µm) · `z` (focus, fine ±5 µm / coarse ±1000 µm, **value shown**) ·
  `α, β` (tilt, ±30°, α horizontal / β vertical).

## A2. Realistic limits for every control (use these as widget min/max)

Drift is now set in **physical nm/s** via `set_drift(vx_nm_per_s=…, vy_nm_per_s=…,
line_jitter_nm=…)` (the server converts to internal units and also *returns* `vx_nm_per_s` /
`vy_nm_per_s` so the UI can display physical drift). The old px/s values (tens to hundreds of
nm/s) were unrealistic and have been corrected.

| quantity | RPC | **recommended UI range** | default | qualitative anchors |
|---|---|---|---|---|
| Drift vx, vy | `set_drift(vx_nm_per_s,…)` | **0 – 10 nm/s** | 0.5 | excellent<0.2 · good~0.5 · moderate~2 · poor~5 · ~10 worst usable |
| Line jitter | `set_drift(line_jitter_nm=…)` | 0 – 0.5 nm | 0.05 | scan instability |
| Probe current | `set_beam(current_pA)` | 1 – 500 pA | 80 | HAADF STEM range; lower = noisier |
| Voltage | `set_beam(voltage_kV)` | 60 – 300 kV | 200 | dropdown {60,80,120,200,300} |
| Magnification | `set_magnification` | 1 – 20 000 kx | 100 kx | atomic columns resolve ≳2000 kx @1024 px |
| Resolution | `set_resolution` | {1024, 2048, 4096} | **1024** | higher → columns at lower mag; 4× cost per step |
| Working thickness | `set_thickness(thickness_nm)` | 5 – 100 nm | 100 | ≤ total (100 nm) |
| Thickness seed | `set_thickness(thickness_seed)` | 0 – 2³¹−1 | 0 | reproducible z-window |
| Damage threshold | `set_specimen(damage_dose_threshold)` | 1e2 – 1e6 e⁻/Å² | 1e4 | organics low · metals high (log slider) |
| Damage rate | `set_specimen(damage_rate)` | 0 – 2 | 0.7 | contrast-loss speed |
| Contamination rate | `set_specimen(contamination_rate)` | 0 – 5 | 1 | carbon build-up speed |
| Dwell time | `device_settings(dwell_us)` | 1 – 100 µs | 20 | lower = noisier (dose) |
| z (focus) | `set_stage({"z"})` | fine ±5 µm / hard ±1000 µm | 0 | **value displayed** |
| α, β tilt | `set_stage({"a","b"})` | ±30° (hard) | 0 | double-tilt |
| x, y | `set_stage({"x","y"})` | ±1500 µm (hard) | 0 | navigation |
| n_grains | sample param | 2 – 12 | 4 | polycrystal |
| n_dislocations | sample param | 1 – 40 | 12 | "many" ≈ 10–20 |
| zone_axis | sample param | {001,011,110,111,112} | **111** | dislocation_crystal; dropdown |
| orientation_mode | sample param | {random_zone_axes, random_3d, in_plane} | **random_zone_axes** | polycrystal; dropdown |
| burgers_A | sample param | 0.5 – 10 Å | **2.525** | = a/√2, FCC slip vector |
| n_particles | sample param | per sample (≤50000) | — | nanoparticle loading |

Corrected **environment presets** (drift now realistic): pristine ≈ 0 nm/s · beam_sensitive ≈
0.5 nm/s (+damage) · contaminating ≈ 1.2 nm/s (+contam) · thick_drifting ≈ 5.8 nm/s (+90 nm
thick) · low_dose ≈ 1.7 nm/s (+25 nm thin, low dwell). Show the nm/s number next to each preset.

**Drift display:** whatever the user sets, echo back the physical speed from `set_drift`'s
return (`vx_nm_per_s`, `vy_nm_per_s`) and, optionally, the accumulated offset so they can see how
far the field has walked.

## A3. Save a 32-bit TIFF (efficient, on demand) — use `twin_io.TwinImageIO`

**Requirement:** a "Save 32-bit TIFF" action for the current view, downloadable from the output
window, done **efficiently** — no growing array of frames, no messy auto-generated filenames.

The helper `twin_io.TwinImageIO` implements the intended design:

- **O(1) memory:** it keeps only the **single most-recent** frame (`io.stash(img, meta=…)` after
  each acquire overwrites the previous one). There is **no gallery of arrays** to bloat RAM.
- **On-demand save:** `io.save_last()` writes that one frame as a **32-bit float TIFF**
  (preserves quantitative range) only when the user clicks Save.
- **Clean names, no clutter:** the filename is auto-built from context —
  `{mode}_{sample-short}_{mag}kx_{res}px.tif` (e.g. `diff_fcc_2000kx_1024px.tif`) — and a small
  integer suffix (`_2`, `_3`) is appended **only if that name already exists**. No timestamps.
  The user may override with `io.save_last(name="my_pattern")`.
- **Metadata embedded:** the acquisition context (mode, sample, mag, resolution, thickness, tilt,
  seeds — whatever you put in `meta`) is written into the TIFF description (ImageJ-readable), so
  a saved file is self-describing.

GUI wiring:
```python
from twin_io import TwinImageIO
io = TwinImageIO(out_dir="/mnt/user-data/outputs/captures")   # or any writable dir

# after every acquisition, stash the frame + its context (cheap, overwrites last):
img = control.acquire_image("haadf")
io.stash(img, meta=dict(mode=control.get_mode()["mode"],
                        sample=current_sample_name,
                        mag_kx=control.get_magnification()["magnification"]/1000,
                        resolution=control.get_resolution()["resolution_px"],
                        thickness_nm=sim.get_thickness()["working_nm"]))

# "Save 32-bit TIFF" button handler:
def on_save_clicked():
    if io.has_image():
        path = io.save_last()          # or save_last(name=user_text) for a custom name
        notify(f"saved {path}")
```
The captures directory can be zipped/downloaded from the output window. Because only the last
frame is retained, the user saves exactly the ones they want, when they want them — nothing
accumulates in memory. (`twin_io` falls back to `.npy` if `tifffile` is unavailable, but install
`tifffile` for real 32-bit TIFFs.)

## A4. Diffraction engine toggle — Kinematical ⇄ abTEM (restated as a requirement)

**Requirement:** a toggle on the control window to obtain **abTEM** (dynamical) diffraction
images in addition to the default kinematical ones.

- Default = **Kinematical** (fast, server-side, `acquire_image` in DIFF mode).
- Toggle = **abTEM**: compute the pattern with `abtem_diffraction.AbtemDiffraction` on the *same
  sample's atoms*, off the UI thread. Because this path is **decoupled from the server**, the GUI
  must apply the current stage tilt to the atoms itself (`build_crystal_tilted` for simple
  crystals, or `tilted_atoms(atoms, tilt_deg_x=a, tilt_deg_y=b)` for arbitrary samples) — server
  α/β do **not** propagate to abTEM automatically. See §2.7 for the full call sequence.
- Present it as a **"Compute dynamical (abTEM)"** action with a visible busy state (seconds to
  tens of seconds), plus a small **frozen-phonons** spinbox (0–16) for the abTEM path only.
  Save the abTEM pattern with the same `io.stash(...)` / `io.save_last()` path (tag
  `meta["engine"]="abTEM"` so the filename/metadata distinguish it).
- If `import abtem` fails, grey out the toggle with a tooltip ("install abtem to enable dynamical
  diffraction").

---

# ADDENDUM (revision 3) — contamination & beam-damage realism; resolution↔pixel note

## A5. Beam damage & contamination — now dose-accurate (e⁻/Å²)

Earlier builds accumulated damage in an **arbitrary unit** that ignored pixel size. That is
fixed: the per-frame exposure is now the **real electron dose**,
`dose (e⁻/Å²) = (I·t / e) / pixel_area`, with `pixel_area = (FOV/resolution)²`. Consequences the
GUI should surface:

- **Damage/contamination speed depends on FOV and resolution**, not just current/dwell — a
  smaller FOV or a higher resolution concentrates dose and damages faster, exactly as on a real
  instrument. (Measured on the old 512→1024 pair: ~5-frame darkening went from ~27 %→~72 %. The
  set is now 1024/2048/4096, so **each step up quadruples the dose per pixel** — expect damage
  to accrue markedly faster at 4096 than the old numbers suggest. Re-measure before quoting.)
- **Damage is gradual**, not catastrophic: contrast is lost as `exp(−rate · log₁₀(dose/threshold))`,
  so it fades smoothly over many frames once the **critical dose** (`damage_dose_threshold`) is
  passed, even when the real dose is far above threshold.
- **Damage darkens** (mass loss removes scatterers → HAADF drops); **contamination brightens**
  (carbon adds mass-thickness → HAADF rises). They are independent toggles.

**Realistic control ranges (use as widget bounds):**

| parameter | RPC | range | default | anchors (critical dose, e⁻/Å²) |
|---|---|---|---|---|
| Damage on/off | `set_specimen(beam_damage_enabled)` | bool | off | — |
| **Critical dose** | `set_specimen(damage_dose_threshold)` | **1e2 – 1e6 e⁻/Å²** (log) | 3e4 | biological ~1–10 · polymers ~10–100 · zeolite/MOF ~1e2–1e3 · oxides ~1e3–1e4 · metals ~1e5–1e7 |
| Damage rate | `set_specimen(damage_rate)` | 0 – 2 | 0.8–1.0 | contrast-loss speed per decade of over-dose |
| Contamination on/off | `set_specimen(contamination_enabled)` | bool | off | — |
| Contamination rate | `set_specimen(contamination_rate)` | 0 – 5 | 1 (preset "contaminating" = 3) | carbon build-up speed |

Preset values after the fix: `beam_sensitive` → critical dose **1e4**, rate 0.8;
`low_dose` → critical dose **5e3**, rate 1.0; `contaminating` → contamination rate **3**. Present
the critical dose on a **log slider** (it spans six decades). A good GUI read-out is the
**accumulated dose** under the beam (`get_specimen()` returns `max_accumulated_dose` and
`max_contamination`) so the user can see how close they are to the critical dose.

> UX tip: because damage/contamination now scale with real dose, a "dose meter" (accumulated
> e⁻/Å² in the current field) is more informative than a frame counter, and it makes the effect
> of FOV/resolution/current/dwell legible at a glance.

## A6. Resolution ↔ pixel conversion — important for beam shift (and any pixel-based control)

**Physical quantities are resolution-independent; pixel-based quantities are NOT.** The nm-per-
pixel of an *acquisition* frame is `FOV / resolution`, so the same pixel count means different
physical distances at 1024 vs 2048 vs 4096.

- **Drift** is defined in physical **nm/s** and converted through the fixed *volume* scale
  (`sample_px_per_um`), so it is **independent of the acquisition resolution** — correct, since
  drift is real stage motion. Do **not** re-scale drift by the display resolution.
- Anything you express in **detector pixels** — beam-shift nudges, ROI boxes, marker sizes,
  the diffraction beamstop radius — now means a *different physical distance* than it did on
  512. Convert through `FOV / resolution` rather than carrying pixel constants across the
  resolution change.
- **Beam shift** (`set_beam({"x":…, "y":…})`) and **any "move by N pixels" / "click-to-position"**
  interaction ARE resolution-dependent. If the GUI lets the user nudge the beam or probe by
  display pixels, convert with the **current** resolution:

  ```python
  res    = control.get_resolution()["resolution_px"]
  fov_nm = control.get_magnification()["field_of_view_um"] * 1000.0
  nm_per_pixel = fov_nm / res                      # depends on BOTH mag and resolution
  shift_nm = n_display_pixels * nm_per_pixel
  ```

  The same on-screen drag is **4× smaller physically at 4096 px than at 1024 px** (for the same
  FOV). Always recompute `nm_per_pixel` from the *live* FOV **and** resolution before turning a
  pixel offset into a physical beam shift (or before labeling a measured distance in nm). If the
  GUI stores beam shift internally in physical units (nm), it stays correct across resolution
  changes; if it stores pixels, it must be rescaled whenever the resolution changes.

- **Practical rule for the GUI:** keep stage/beam/drift state in **physical units** (µm, nm,
  nm/s) everywhere, and convert to/from pixels only at the moment you read a mouse position or
  draw an overlay — using the live `FOV/resolution`. That makes every control resolution-safe.

---

# ADDENDUM (revision 4) — how time-dependent effects advance (drift vs dose)

**Two different clocks — the GUI should drive them accordingly.**

- **Drift = real wall-clock time, materialized at each acquire.** On every `acquire_image`, the
  server adds `velocity × (real seconds since the last acquire)` to the accumulated offset. So
  the nm/s you set means nm per *real* second. Drift does **not** advance in a background thread
  while the sample sits idle — it only updates when you acquire, applying all the elapsed time at
  once. Implications:
  - A **Live mode** (re-acquire every ~100–300 ms) shows smooth, continuous drift, like a real
    scope. This is the recommended way to visualize drift.
  - A single acquire after a long pause applies one lump of drift for the elapsed time. To avoid
    a jarring teleport, the server now **caps the per-frame elapsed time** at
    `drift["max_dt_s"]` (default 2.0 s). You can expose this cap if desired, but the default is
    sensible: idle gaps don't teleport, live cadence is unaffected.
  - `set_environment(...)` and `set_drift(reset_accum=True)` reset both the accumulated offset
    **and** the drift clock — call one of these after loading a sample / re-centering so drift
    starts fresh from "now".
  - To show how far the field has walked, read `get_drift()["accum_x_px"/"accum_y_px"]` (volume
    pixels; ×~26 nm for physical distance) or just reset and let Live mode show it.

- **Beam damage & contamination = accumulated dose, per acquire (not wall-clock).** Each acquire
  adds the frame's real electron dose (e⁻/Å²) to the exposed region; nothing accrues while idle.
  This matches reality (damage happens only while the beam is dosing the specimen). So a "dose
  meter" driven by `get_specimen()["max_accumulated_dose"]` is the right read-out, and letting a
  Live mode run *does* keep damaging/contaminating because each frame adds dose.

**Net:** for a faithful live view, run a Live loop; drift will move the field in real time and
damage/contamination will build with each frame. If you only take single frames on demand, drift
advances by the (capped) real gap between them, and dose advances by one frame each.
